import SwiftUI

struct ContentView: View {
    @ObservedObject var fileMover = KeywordFileMover()

    var body: some View {
        VStack {
            List {
                ForEach(fileMover.configurations) { config in
                    VStack(alignment: .leading) {
                        Text("Input Folder: \(config.inputFolder)")
                        Text("Output Folder: \(config.outputFolder)")
                        Text("Keywords: \(config.keywords.joined(separator: ", "))")
                    }
                }
                .onDelete(perform: deleteItems)
            }
            .frame(minHeight: 200)
            
            HStack {
                Button(action: addConfiguration) {
                    Text("Add Configuration")
                }
                
                Button(action: {
                    fileMover.moveFiles()
                }) {
                    Text("Run Now")
                }
            }
            .padding()
        }
        .padding()
    }
    
    private func addConfiguration() {
        let newConfig = FolderConfig(inputFolder: "", outputFolder: "", keywords: ["example_keyword"])
        fileMover.configurations.append(newConfig)
        fileMover.saveConfiguration()
    }
    
    private func deleteItems(at offsets: IndexSet) {
        fileMover.configurations.remove(atOffsets: offsets)
        fileMover.saveConfiguration()
    }
}
