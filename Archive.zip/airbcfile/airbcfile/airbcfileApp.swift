//
//  airbcfileApp.swift
//  airbcfile
//
//  Created by Marius Dima on 12.06.2024.
//

import SwiftUI

@main
struct airbcfileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
