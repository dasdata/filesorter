import Foundation
import PDFKit
//import Docx

struct FolderConfig: Codable, Identifiable {
    var id = UUID()
    let inputFolder: String
    let outputFolder: String
    let keywords: [String]
}

class KeywordFileMover: ObservableObject {
    @Published var configurations: [FolderConfig] = []

    private let configFilePath: URL

    init() {
        let homeDirectory = FileManager.default.homeDirectoryForCurrentUser
        configFilePath = homeDirectory.appendingPathComponent(".airbc/config.json")

        if !FileManager.default.fileExists(atPath: configFilePath.path) {
            generateConfigFile()
        }

        loadConfiguration()
    }

    func loadConfiguration() {
        do {
            let data = try Data(contentsOf: configFilePath)
            configurations = try JSONDecoder().decode([FolderConfig].self, from: data)
        } catch {
            print("Failed to load configuration: \(error)")
        }
    }

    func saveConfiguration() {
        do {
            let data = try JSONEncoder().encode(configurations)
            try data.write(to: configFilePath)
        } catch {
            print("Failed to save configuration: \(error)")
        }
    }

    func moveFiles() {
        for config in configurations {
            guard let inputURL = URL(string: config.inputFolder),
                  let outputURL = URL(string: config.outputFolder) else { continue }

            let fileManager = FileManager.default
            do {
                let files = try fileManager.contentsOfDirectory(at: inputURL, includingPropertiesForKeys: [.contentModificationDateKey], options: .skipsHiddenFiles)
                
                let filteredFiles = files.filter { $0.pathExtension.lowercased() == "txt" || $0.pathExtension.lowercased() == "pdf" || $0.pathExtension.lowercased() == "docx" }
                
                let sortedFiles = filteredFiles.sorted { file1, file2 in
                    let date1 = (try? file1.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? Date.distantPast
                    let date2 = (try? file2.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? Date.distantPast
                    return date1 < date2
                }

                for file in sortedFiles {
                    let content: String?
                    if file.pathExtension.lowercased() == "txt" {
                        content = try? String(contentsOf: file, encoding: .utf8)
                    } else if file.pathExtension.lowercased() == "pdf" {
                        content = readPDFFile(file)
                    } else if file.pathExtension.lowercased() == "docx" {
                       // content = readDocxFile(file)
                        content =  ""
                    } else {
                        continue
                    }
                    
                    if let content = content {
                        let score = scoreContent(content, with: config.keywords)
                        if score > 0 {
                            let destination = outputURL.appendingPathComponent(file.lastPathComponent)
                            try? fileManager.moveItem(at: file, to: destination)
                        }
                    }
                }
            } catch {
                print("Failed to read contents of directory: \(error)")
            }
        }
    }

    private func readPDFFile(_ url: URL) -> String? {
        guard let pdfDocument = PDFDocument(url: url) else { return nil }
        let pageCount = pdfDocument.pageCount
        var text = ""
        for index in 0..<pageCount {
            if let page = pdfDocument.page(at: index), let pageContent = page.string {
                text += pageContent
            }
        }
        return text
    }

 //   private func readDocxFile(_ url: URL) -> String? {
 //       do {
 //           let docx = try Docx(fileURL: url)
 //           return try docx.readText()
 //       } catch {
 //           print("Failed to read DOCX file: \(error)")
 //           return nil
 //       }
 //   }

    private func scoreContent(_ content: String, with keywords: [String]) -> Int {
        return keywords.reduce(0) { count, keyword in
            count + content.components(separatedBy: keyword).count - 1
        }
    }

    private func generateConfigFile() {
        let defaultFolders = [
            "Downloads": "Downloads_Processed",
            "Documents": "Documents_Processed",
            "Desktop": "Desktop_Processed"
        ]
        
        var folderConfigs: [FolderConfig] = []

        for (inputFolderName, outputFolderName) in defaultFolders {
            let homeDirectory = FileManager.default.homeDirectoryForCurrentUser
            let inputFolderURL = homeDirectory.appendingPathComponent(inputFolderName).path
            let outputFolderURL = homeDirectory.appendingPathComponent(outputFolderName).path

            let keywords = ["example_keyword1", "example_keyword2"]
            
            let folderConfig = FolderConfig(
                inputFolder: inputFolderURL,
                outputFolder: outputFolderURL,
                keywords: keywords
            )
            
            folderConfigs.append(folderConfig)
        }

        do {
            let data = try JSONEncoder().encode(folderConfigs)
            try data.write(to: configFilePath)
            configurations = folderConfigs
        } catch {
            print("Failed to write configuration file: \(error)")
        }
    }
}
