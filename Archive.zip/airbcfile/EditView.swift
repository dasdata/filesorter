import SwiftUI

struct EditView: View {
    @Binding var config: FolderConfig

    var body: some View {
        VStack {
            TextField("Input Folder", text: $config.inputFolder)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Output Folder", text: $config.outputFolder)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Keywords (comma-separated)", text: Binding(
                get: { config.keywords.joined(separator: ", ") },
                set: { config.keywords = $0.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) } }
            ))
            .padding()
            .textFieldStyle(RoundedBorderTextFieldStyle())

            Button(action: {
                // Save configuration when done editing
                // In SwiftUI, changes to the binding are automatically propagated
            }) {
                Text("Save")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
