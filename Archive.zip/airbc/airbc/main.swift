import Foundation

struct FolderConfig: Codable {
    let inputFolder: String
    let outputFolder: String
    let keywords: [String] // Store keywords as an array of strings
}

struct KeywordFileMover {
    let inputOutputPairs: [(inputFolder: URL, outputFolder: URL, keywords: [String])]

    func scoreContent(_ content: String, with keywords: [String]) -> Int {
        return keywords.reduce(0) { count, keyword in
            count + content.components(separatedBy: keyword).count - 1
        }
    }

    func moveFiles() {
        for pair in inputOutputPairs {
            let fileManager = FileManager.default
            do {
                let files = try fileManager.contentsOfDirectory(at: pair.inputFolder, includingPropertiesForKeys: [.contentModificationDateKey], options: .skipsHiddenFiles)
                
                // Sort files by modification date
                let sortedFiles = files.sorted { file1, file2 in
                    let date1 = (try? file1.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? Date.distantPast
                    let date2 = (try? file2.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? Date.distantPast
                    return date1 < date2
                }

                for file in sortedFiles {
                    if let content = try? String(contentsOf: file, encoding: .utf8) {
                        let score = scoreContent(content, with: pair.keywords)
                        if score > 0 { // You can set a threshold here if needed
                            let destination = pair.outputFolder.appendingPathComponent(file.lastPathComponent)
                            try? fileManager.moveItem(at: file, to: destination)
                        }
                    }
                }
            } catch {
                print("Failed to read contents of directory: \(error)")
            }
        }
    }
}

func generateConfigFile(path: String) {
    let fileManager = FileManager.default
    let homeDirectory = fileManager.homeDirectoryForCurrentUser
    
    let defaultFolders = [
        "Downloads": "Downloads_Processed",
        "Documents": "Documents_Processed",
        "Desktop": "Desktop_Processed"
    ]
    
    var folderConfigs: [FolderConfig] = []

    for (inputFolderName, outputFolderName) in defaultFolders {
        let inputFolderURL = homeDirectory.appendingPathComponent(inputFolderName)
        let outputFolderURL = homeDirectory.appendingPathComponent(outputFolderName)

        if !fileManager.fileExists(atPath: outputFolderURL.path) {
            do {
                try fileManager.createDirectory(at: outputFolderURL, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print("Failed to create output directory: \(error)")
                continue
            }
        }

        // Example keywords; update as necessary
        let keywords = ["example_keyword1", "example_keyword2"]
        
        let folderConfig = FolderConfig(
            inputFolder: inputFolderURL.path,
            outputFolder: outputFolderURL.path,
            keywords: keywords
        )
        
        folderConfigs.append(folderConfig)
    }

    do {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        let jsonData = try encoder.encode(folderConfigs)
        
        // Ensure the directory for the config file exists
        let configURL = URL(fileURLWithPath: path)
        let configDirectory = configURL.deletingLastPathComponent()
        if !fileManager.fileExists(atPath: configDirectory.path) {
            try fileManager.createDirectory(at: configDirectory, withIntermediateDirectories: true, attributes: nil)
        }
        
        try jsonData.write(to: configURL)
        print("Configuration file created at \(path)")
    } catch {
        print("Failed to write configuration file: \(error)")
    }
}

func configFilePath() -> String {
    let homeDirectory = FileManager.default.homeDirectoryForCurrentUser
    return homeDirectory.appendingPathComponent(".airbc/config.json").path
}

func readConfiguration(from path: String) -> [(URL, URL, [String])] {
    let fileManager = FileManager.default
    guard let configData = fileManager.contents(atPath: path) else {
        print("Could not read configuration file.")
        return []
    }
    let decoder = JSONDecoder()
    do {
        let folderConfigs = try decoder.decode([FolderConfig].self, from: configData)
        return folderConfigs.map {
            (URL(fileURLWithPath: $0.inputFolder),
             URL(fileURLWithPath: $0.outputFolder),
             $0.keywords)
        }
    } catch {
        print("Failed to decode configuration file: \(error)")
        return []
    }
}

// Main function to handle both configuration generation and file moving
func main() {
    let configPath = configFilePath()

    let fileManager = FileManager.default
    if !fileManager.fileExists(atPath: configPath) {
        generateConfigFile(path: configPath)
    }

    let configuration = readConfiguration(from: configPath)
    let mover = KeywordFileMover(inputOutputPairs: configuration)

    // Run continuously, checking every 60 seconds
    while true {
        mover.moveFiles()
        sleep(60)
    }
}

main()
