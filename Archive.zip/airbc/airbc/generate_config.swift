import Foundation

struct FolderConfig: Codable {
    let inputFolder: String
    let outputFolder: String
    let keywords: [String]
}

func generateConfigFile(path: String) {
    let fileManager = FileManager.default
    let homeDirectory = fileManager.homeDirectoryForCurrentUser
    
    let defaultFolders = [
        "Downloads": "Downloads_Processed",
        "Documents": "Documents_Processed",
        "Desktop": "Desktop_Processed"
    ]
    
    var folderConfigs: [FolderConfig] = []

    for (inputFolderName, outputFolderName) in defaultFolders {
        let inputFolderURL = homeDirectory.appendingPathComponent(inputFolderName)
        let outputFolderURL = homeDirectory.appendingPathComponent(outputFolderName)

        if !fileManager.fileExists(atPath: outputFolderURL.path) {
            do {
                try fileManager.createDirectory(at: outputFolderURL, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print("Failed to create output directory: \(error)")
                continue
            }
        }

        let keywords = ["example_keyword"]
        
        let folderConfig = FolderConfig(
            inputFolder: inputFolderURL.path,
            outputFolder: outputFolderURL.path,
            keywords: keywords
        )
        
        folderConfigs.append(folderConfig)
    }

    do {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        let jsonData = try encoder.encode(folderConfigs)
        try jsonData.write(to: URL(fileURLWithPath: path))
        print("Configuration file created at \(path)")
    } catch {
        print("Failed to write configuration file: \(error)")
    }
}

func configFilePath() -> String {
    let homeDirectory = FileManager.default.homeDirectoryForCurrentUser
    return homeDirectory.appendingPathComponent(".keywordfilemover/config.json").path
}

let configPath = configFilePath()

let fileManager = FileManager.default
if fileManager.fileExists(atPath: configPath) {
    print("Configuration file already exists at \(configPath)")
} else {
    generateConfigFile(path: configPath)
}
